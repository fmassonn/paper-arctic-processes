Font Name : Acephimere
Created By Dichi

This font is 100% free!
Please note that this font is under heavy development.
Currently I've finished the regular weight (+ italic) and more weights will
be added in the future! I'll try my best to create it as soon as possible,
so you will use the font in your project in no time. :)

If you need help, feel hesitate, or have any suggestion,
please reach me at diciganteng01@icloud.com